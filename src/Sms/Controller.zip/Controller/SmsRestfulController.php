<?php

namespace Sms\Controller;
 
use Zend\Mvc\Controller\AbstractRestfulController;
use DateTime;
use DateTimeZone;
//require_once 'Zend/Date.php';
//use Zend_Date;
 
//date_default_timezone_set('Africa/Nairobi');
class SmsRestfulController extends AbstractRestfulController
{
	protected $SmsTable;
    protected $RegistrationTable;
    protected $ProgressTable;
	protected $SmsgatewayTable;
	protected $SmsSwitchTable;
	protected $UserCertificatesTable;
	protected $SmsSettingsTable;
	protected $UserTable;
	protected $CertificatesTable;
	protected $CourseTable;
    protected $QuizTable;
    protected $QuestionTable;
    protected $ChoicesTable;
    protected $QuestionRandTable;
    protected $QuestionResponsesTable;
	protected $UserSmsInteractionsTable;
	protected $UserAssignmentTable;
	protected $InvitationTable;
	protected $ClassTable;
	
	 public function createAction()
    {
	//lets first check the sms gateway being used
	//echo "hapa";
      	//$sms_gateway =$this->getSmsgatewayTable()->getSmsgateway();
       //echo $sms_gateway;
	   
//lets get the sms_gateway_id and use it to 
	 	$sms_gateway_id = $_REQUEST['sms_gateway_id'];
	  
//now that we have the gateway id, lets use the gateway to get the incoming message details from our gateway

	  $received_msg['from_number'] = $_REQUEST['from'];
	  $received_msg['message'] =  $_REQUEST['message'];
     	//print_r($received_msg);
//where do we direct the SMS? We get the action_id from our wonderful switch
	  $action = $this->getSmsSwitchTable()->getSmsSwitchAction($received_msg['message']);
		$action_id = $action->action_id;

    //print_r($action);
//exit;
//then we use the action_id to Accept and Move on
//echo $action_id;
if($action_id<9){
		switch ($action_id) {
       	case "1":
	    $output = $this->register($received_msg['from_number'],$received_msg['message']); 
         // $output = "registration";
        break;  
    	case "2":
      $output = $this->test($received_msg['from_number'],$received_msg['message']); 
       	//testing($received_msg['from_number'],$received_msg['message']);
      	break;   
   		case "3":
		//claim_reward($received_msg['from_number'],$received_msg['message']);
		  $output = "Be easy on the rewards, earn them first then request";
       	break;
		case "4":
		  $output = "Invalid certificate";
		  //$output = $this->verify_certificate($received_msg['from_number'],$received_msg['message']);
       	break;
		case "5":
		//take_survey($received_msg['from_number'],$received_msg['message']);
		 $output = "Sorry we don't have this survey yet, we'll notify you when it is available";
       	break;
		case "6":
		 $output = "This is the payment module";
       	break;
		case "7":
		$output=$this->checkSession($received_msg['from_number'],$received_msg['message']);     
      	break; 
		case "8":
		$output=$this->invite_users();     
      	break; 		
		}
		}else{
			$output = $action->message;
		}
		//replace any template tags first
		//$search_for   = array("{{register}}","{{test}}", "{{cert}}", "{{reward}}", "{{payment_for}}");
		//$replace_with = array("Steve","GCAKENYA.COM", "00038", "3000","1 year Domain and Hosting Renewal");
		//$output4 = str_replace($search_for, $replace_with, $output3);
		
		
	   $output = $this->send_output($sms_gateway_id,$output,$received_msg['from_number']);
	   $response = $this->getResponseWithHeader()
	   					->setContent($output);
        return $response;
    }

//lets pull what has to be sent out
public function invite_users(){
	$PendingInvites = $this->getInvitationTable()->getPendingInvites();
	//we need to know the test in the courses first
	$newarray = array();
	
	foreach ($PendingInvites['invitation'] as $key1 => $value) {
		$course_classes = $this->getClassTable()->getClasses($value);
		//lets get tests
		if($course_classes !=0){
		foreach ($course_classes as $key => $value) {			
			
		$testIds = $this->getQuizTable()->getQuizdetail($value);
			if($testIds !=0){
			foreach ($testIds as $key => $value) {
				array_push($PendingInvites['invitation'][$key1],$value);
				
			}				
			}
		}
		}
		//if($course_classes->class_id > 0){
			
						
			
		//}
	}
	
	array_push($newarray,$PendingInvites);
	//$course_tests = $this->getCourseTable()->getTests($PendingInvites['invitation'][2]);
	
	//return $newarray;
	return $PendingInvites;
	
	
}

    public function getResponseWithHeader()
    {
        $response = $this->getResponse();
        $response->getHeaders()
                 //make can accessed by *  
                 ->addHeaderLine('Access-Control-Allow-Origin','*')
                 //set allow methods
                 ->addHeaderLine('Access-Control-Allow-Methods','POST PUT DELETE GET');
         
        return $response;
    }

//let us send out the output
	public function send_output($sms_gateway_id,$output,$from_number){
             
		//If we are using SMSSync id=1 and we do the following
	if($sms_gateway_id==1){
        
		    if (is_array($output)){
		    	//print_r($output);
		    	//exit();
				if(!empty($output[1]['winners'])){
			$records = array();
					foreach ($output[1]['winners'] as $key => $data) {
						$key = $key+1;
         array_push($records, array('message'=>'Congratulations, you were ranked number '.$key.' in #Trial'.$output[4].': '.$output[3].'. You will receive Ksh.'.$output[2].' in airtime shortly.', 'to'=>$data[2]
      ));
	  array_push($records, array('message'=>$output[2].'#'.$data[2], 'to'=>'140'));
	  
           # code...
         }
				
			//array_push($records, array('message'=>$output[0], 'to'=>$from_number));
					
				}
	if(!empty($output['invitation'])){
			$records = array();
					foreach ($output['invitation'] as $key => $data) {
						//$key = $key+1;
      array_push($records, array('message'=>"You have been invited to ".$data[3].". Please take the course material online at akengo.com and attempt the test by replying with #Trial".$data[4], 'to'=>$data[0]));
	  
           # code...
         }
				
			//array_push($records, array('message'=>$output[0], 'to'=>$from_number));
					
				}	
				
				else{
				
         $records = array();         
         foreach ($output as $data) {
          array_push($records, array('message'=>$data, 'to'=>$from_number));
           # code...
         }
				}
           
        }else{
		    $records[]= array( 'message' => $output, 'to' => $from_number);	
			  }
        $sms_array= array();
				$sms_array[] = array('success'=>"true",'secret'=>"",'task'=>"send",'messages'=>$records);
				$payload= array('payload'=>$sms_array[0]);
				//header('content-type: application/json; charset=utf-8');
				//echo json_encode($payload);
		
return json_encode($payload);
		
	}
	//If we are using Africastalking we do the following
	if($sms_gateway_id==2){
		//we will write this code from Africastalking documentation
		//
		
	}
	/*future sms gateway will be setup here to be used
	 if($sms_gateway_id==X){
		we will write this code from Africastalking documentation
 		
	}*/

	else{
		//
	}
		
	}	
	//lets take a test

  public function test($from_number,$message){

  $user_details = $this->getUserTable()->checkUserDetails($from_number);
  //return $user_details;
  //exit;
  $user_exists = $user_details->from_number;
  if($user_exists >0){
    //set test session to test and start the progress

    //is the test private or not
    //if private you check if the user if invited
    $progress = $user_details->progress;
    //lets check if the user has started the test
    if($progress<1){
      //get test question id
  $testID = $this->getTestID($message);

    // return $testID;
    // exit();
    //getSetting on whether users are allowed to take a test more than once. 0 for not allowed, 1 for allowed
    
    $quizdetails =  $this->getQuizTable()->getQuizDetails($testID);
  //return $quizdetails->id;
  //exit();
  
  if($quizdetails->id==0){
    // if the test is not available

    $output = $this->getSmsSettingsTable()->getSetMessage('no_test_with_that_id')->value;
    //$output = $action->prefix;
    //create log
			$data=array(
                            'user_id'=>$user_details->id,
                            'activity'=>22,
                            'quiz_id'=>$testID,
                            'message_received'=>$message
                        ); 
  		//create data points
  		$log = $this->getUserSmsInteractionsTable()->createActivity($data);
		//end of log creation
    
  }else{
  //if we first randomize the order in which we are going to serve the questions
    //return $user_details->id;
  //exit();
  //check how many times a user can take a test
  $test_permission = $this->getSmsSettingsTable()->getSetMessage('how_many_times_a_user_can_take_a_test')->value;
  //return $test_permission;
  //exit();
$taken = $this->getUserSmsInteractionsTable()->getCompletedExamInteraction($user_details->id,$testID);

//return $taken;
//exit();

 if($taken[0]>=$test_permission ){
		$not_allowed_message = $this->getSmsSettingsTable()->getSetMessage('you_are_not_allowed_to_retake_this_test')->value;
			
			//lets do replaces
		if($test_permission==1){
			$times = 'once';
		}else{
			$times = $test_permission.' times';
		}
		
		
		//lets deal with timezone issues
		$Date = $this->getLocalTime($taken[1]->timestamp);
			
		$replace_with = array($message, $Date, $taken[1]->score,$times);
        $search_for   = array("{{test_id}}", "{{date}}", "{{score}}","{{times}}");
		$output = str_replace($search_for, $replace_with, $not_allowed_message);
		
		//return $output;
		//exit();
			
			
		}
		
	
	//if there is not set test permission we go on
	else{
  
   $randomizedorder = $this->rand_test($user_details->id,$testID,$quizdetails->id);
  //return $randomizedorder;
  //exit();
	if($randomizedorder == 0){
	$output =  $this->getSmsSettingsTable()->getSetMessage('no_questions_set')->value;
  
  $output = str_replace("{{test}}", $message, $output); 
  //exit();
  //create log
			$data=array(
                            'user_id'=>$user_details->id,
                            'activity'=>23,
                            'quiz_id'=>$testID,
                            'message_received'=>$message
                        ); 
  		//create data points
  		$log = $this->getUserSmsInteractionsTable()->createActivity($data);
		//end of log creation
		 
}else{
   //lets get the introduction text
    $intro_text = $quizdetails->intro_text;
    //echo $quizdetails->id;
    $QuestionDetails = $this->getQuestionTable()->getQuestion($randomizedorder[0]);
    $firstquestion = $QuestionDetails->question_text;
    //$firstquestionID = $QuestionDetails->id;
    //echo $firstquestionID." ".$randomizedorder[0];
   //exit();
    //lets get the choices
   $Choices = $this->getChoicesTable()->getChoices($randomizedorder[0]);
   
   //since we have everything together, let's update the progress to 1
   $data=array(   
            'session'=>2,
            'test_to_take'=>$testID,
            'progress'=>$randomizedorder[0]
            );
    $this->getUserTable()->updateUser($data,$from_number);
    $output = $intro_text.PHP_EOL." 1.".$firstquestion.PHP_EOL.$Choices;
	//create log
			$data=array(
                            'user_id'=>$user_details->id,
                            'activity'=>6,
                            'quiz_id'=>$testID,
                            'message_received'=>$message
                        ); 
  		//create data points
  		$log = $this->getUserSmsInteractionsTable()->createActivity($data);
		//end of log creation
  }
  }
  }
  }
if($progress>0){
 $selected_option = '';
 $testID = $user_details->test_to_take;
 $user_id = $user_details->id;
 $question_id = $progress;
 //Lets get all the choices possibilities first
 $ChoicesData = $this->getChoicesTable()->getChoicesData($question_id);
 //$keys = '';
 // return $ChoicesData;
// exit();

if(empty($ChoicesData)){
	$selected_option = $message;
}
else{
 $message = strtolower($message);
 foreach ($ChoicesData as $key => $value) {
 	//check if they are equal
 	
 	
 	if((trim(strtolower($key)) == $message)){
 		foreach ($value as $key1 => $value1){
 		$selected_option = $value1[0]; 
		}	
		//if they fail to map then selected option is empty but we don't stop there, 
		//do a second check to check if the user sent the value instead
 	}if(empty($selected_option)){ 		
 		foreach ($value as $key1 => $value1){
 		if((trim(strtolower($value1[1])) == $message)){
 		$selected_option = $value1[0];
		} 
		}	
	}
    }
}
 
 
if(empty($selected_option)){
 	//if the validation is not passed then we return the user with the question again
 		$error_message = $this->getSmsSettingsTable()->getSetMessage('selected_choice_not_one_of_the_options')->value;;
 		$QuestionDetails = $this->getQuestionTable()->getQuestion($question_id);
        $nextquestion = $QuestionDetails->question_text;
   // return $next_question_id;
	//exit();
    //lets get the choices
        $Choices = $this->getChoicesTable()->getChoices($question_id);
		//create log
			$data=array(
                            'user_id'=>$user_details->id,
                            'activity'=>8,
                            'quiz_id'=>$testID,
                            'question_id'=>$question_id,
                            'message_received'=>$message
                        ); 
  		//create data points
  		$log = $this->getUserSmsInteractionsTable()->createActivity($data);
		//end of log creation

        $output = $error_message.PHP_EOL.$nextquestion.PHP_EOL.$Choices;
		return $output;
 }else{
 
 // return $selected_option;
 // exit();
 
  //$selected_option
  //we get the answer to the previous question

  $data=array(    
    
            'quiz_id'=> $testID,
            'user_id'=> $user_id,
            'question_id'=>$question_id,
            'answer_id'=>$selected_option
            );
        //print_r($data);
  //feed in the response for the previous question
  $this->getQuestionResponsesTable()->createResponse($data);
  
  	//create log
			$data=array(
                            'user_id'=>$user_details->id,
                            'activity'=>7,
                            'quiz_id'=>$testID,
                            'question_id'=>$question_id,
                            'message_received'=>$message
                        ); 
  		//create data points
  		$log = $this->getUserSmsInteractionsTable()->createActivity($data);

   // exit();
  $QuestionOrder = $this->getQuestionRandTable()->getQuestionOrder($testID,$user_id);
  //array_splice($QuestionOrder, count($QuestionOrder),-1);
  // print_r($QuestionOrder);
  // exit();
  unset($QuestionOrder[0]);
// return $QuestionOrder[1];
// exit();
  if(empty($QuestionOrder[1])){
    $data=array(   
            'session'=>0,
            'test_to_take'=>0,
            'progress'=>0
            );
    $result = $this->getUserTable()->updateUser($data,$from_number);
	//lest go to the marker now
	//$output = "hapa";
	
	//create log
			$data=array(
                            'user_id'=>$user_details->id,
                            'activity'=>9,
                            'quiz_id'=>$testID,
                            //'question_id'=>$question_id,
                            //'message_received'=>$message
                        ); 
  		//create data points
  		$log = $this->getUserSmsInteractionsTable()->createActivity($data);
		//end of log creation
	
	//this will give the score
	$output = array();
	array_push($output,$this->SmsMarker($user_id,$testID));
	
	//check if test has airtime reward af the user qualifies for it user qualifies for a reward
	$quizdetails =  $this->getQuizTable()->getQuizDetails($testID);
	if(!empty($quizdetails->airtime_reward)){
		//quiz has a test reward so we check if all those who had been invited, have completed
		//we need the class ID in order to go to the next step
		$class_id = $quizdetails->class_id;
		//we use the class id to get the course ID
		$courseID = $this->getClassTable()->getCourseID($class_id)->course_id;
		
		//we get an array of phone numbers
		$invited_users = $this->getInvitationTable()->getInvitedUsers($courseID);
		//for each phone number, 
		//array_push($output,$invited_users);
		//return $output;
		//exit();
		
		$incomplete = 0;
		$rank = array();
		foreach ($invited_users as $key => $value) {
			$userPhone = $this->getUserTable()->checkUserDetails($value);

			//does the user exist
			if($userPhone->id>0){
			
			//we get the user id and check if he/she has completed the exam
			
			$completed_users = $this->getUserSmsInteractionsTable()->getScore($userPhone->id,$testID);
			//once we get the first person who has not completed the exam, we break and send back message, you recieve reward if you win
			$completed = $completed_users->user_id;
			if($completed==0){
				$incomplete = $incomplete+1;
				//$reply = "You will be notified if you win airtime";
				//array_push($output,$reply);
				return $output;
				exit();
			}
		
			else{
				array_push($rank,$userPhone->id = array($completed_users->score,$completed_users->timestamp,$value));
								//we rank users as we progress
				
				
				
			}
			
			
			}else{
				$incomplete = 1;
				$reply = "You will be notified if you win airtime";
				//array_push($output,$reply);
				//exit();
		}
		
			
		}
		if($incomplete==0){
			//array_push($output,$rank);
			//return $output;
			
			//we run the lottery
			//get the number of users who qualify for the reward
			$number_of_winners = $quizdetails->no_of_people;
			//get the top 3 scorers:
			//rank according to score
			foreach ($rank as $key => $row) {
    $score[$key] = $row[0];
    $dates[$key] = $row[1];
     }
			array_multisort($score, SORT_DESC, $dates, SORT_ASC, $rank);
			//$winners = array();
		$winners = array_slice($rank, 0, $number_of_winners);
		//$winners = 
			array_push($output,array('winners' => $winners));
			array_push($output,$quizdetails->airtime_reward,$quizdetails->quiz_name,$quizdetails->id);
					}else{
					
						$reply = "You will be notified if you win airtime";
				array_push($output,$reply);
					}
		
		
		return $output;
		//check the timestamp to confirm when these guys completed the test
		//lets declaire the final winners
		//$winners = array();
		
	}
	
	//lets check if the user qualifies for a reward.
    //$output = 'You will get your results shortly';
	// we should go to the merker now

  }else{

foreach ( $QuestionOrder as $key=>$val ){

    $finalArray[] = $QuestionOrder[$key];

}


  //lets update the json object
$status = 0;
$order = json_encode($finalArray);
$this->getQuestionRandTable()->updateRandomization($order,$testID,$user_id,$status);
  //print_r($QuestionOrder);
  //exit();
 
  // foreach ($QuestionOrder as $key => $value) {
  //   $key[$key] = $key;
  //   $value[$key] = $value;
  // }
  reset($QuestionOrder);
  $next_question_id = reset($QuestionOrder);
  //print_r($next_question_id);
  //Next question number
 // $no = key($QuestionOrder)+1;
  //echo $no;
  //print_r($key[]);


  
  //$next_question_id = $QuestionOrder[1];


   $QuestionDetails = $this->getQuestionTable()->getQuestion($next_question_id);
   $nextquestion = $QuestionDetails->question_text;
   // return $next_question_id;
	//exit();
    //lets get the choices
   $Choices = $this->getChoicesTable()->getChoices($next_question_id);
   
   //since we have everything together, let's update the progress to 1
   $data=array(   
            'session'=>2,
            'test_to_take'=>$testID,
            'progress'=>$next_question_id
            );
    $result = $this->getUserTable()->updateUser($data,$from_number);
    if($result){


      $output = $nextquestion.PHP_EOL.$Choices;
    }

    
 } 


}
}
  }
//if the user has started the test then we go on as per the progress
    else{
    	
   $intro_message = $this->getSmsSettingsTable()->getSetMessage('register_before_test')->value; 
		
		
   $first_question = $this->getSmsSettingsTable()->getSetMessage('appl_welcome_message')->value;
  
   //$referred = $message;
  //$first_question = $this->register($from_number,$message);
  $id = $this->getUserTable()->createUserWithReferral($from_number,$message);
  
   $data=array(
                            'user_id'=>$id,
                            'activity'=>1,
                            //'progress'=>1,
                            'message_received'=>$message
                        );  
  		
  		$log = $this->getUserSmsInteractionsTable()->createActivity($data);
   
  
  $output = $intro_message.". ".$first_question;
  //$output = "hapa";
    }
    return $output;
  }

//Lets mark exams

public function SmsMarker($user_id,$testID){
	//lets get question IDs first:
	
	
	$questionIDs = $this->getQuestionTable()->getQuestionIDs($testID);
	//get the response for the user for the particular test
	$no_of_questions = count($questionIDs);
	$no_of_correct_responses = 0;
	foreach ($questionIDs as $key => $value) {
		//get the user response for that question id
		$user_response = $this->getQuestionResponsesTable()->getresponse($value,$user_id)->answer_id;
		
		//get the right question and compare
		
		$right_answer = $this->getChoicesTable()->getRightChoice($value)->id;
		if($right_answer==0){
			//when there is not set correct answer
		}else{
	// return $right_answer;
	// exit();
		if( $user_response == $right_answer){
 		$no_of_correct_responses = $no_of_correct_responses+1;
		} 
		}

 }
	$percentage = $no_of_correct_responses / $no_of_questions;
	if($no_of_correct_responses>0){
	$percentage = $percentage * 100;
	
	$percentage = number_format($percentage, 0, '.', '');
	}else{
		$percentage = 0;
	}
	//let us feed it the data to the user assignment table
	
	//lets log the marking
	
	
	//lets log the marking
	$data=array(
                            'user_id'=>$user_id,
                            'activity'=>10,
                            'score'=>$percentage, 
                            'quiz_id'=>$testID,
                            //'message_received'=>$message
                        ); 
	$log = $this->getUserSmsInteractionsTable()->createActivity($data);
	
	if($percentage>=50){
		$pass = 1;
	$output= "Congratulations, you got ".$no_of_correct_responses." out of ".$no_of_questions." which is .".$percentage."%. Thanks for using akengo."; 
	//$this->getQuestionResponsesTable()->getresponse();
	}else{
		$pass = 0;
		$output= "Seems you will need more effort, you got ".$no_of_correct_responses." out of ".$no_of_questions." which is ".$percentage."%. Thanks for using akengo."; 
	}
	
	$data=array(			
							'assignment_id'=>$testID,
                            'user_id'=>$user_id,
                            'status'=>$pass,
                            'score'=>$percentage, 
                            //'completed_at' => now(),
                            //'quiz_id'=>$testID,
                            //'message_received'=>$message
                        ); 
	$result = $this->getUserAssignmentTable()->createScore($data);
	//
	return $output;
	
}


//lets deal with server time issues
public function getLocalTime($timestamp){
//convert current timestamp to unix timestamp	
$newtime = strtotime($timestamp);
//do the magic by adding the offset between server time('America/Denver') and ('Africa/Nairobi')
$newadjustedtime = date('l jS \of F Y h:i A',strtotime($timestamp) + 9 * 3600);
return $newadjustedtime;
//exit();

}

    //this function is to be removed later

  public function rand_test($user_id,$testID,$quizID){
//get all questionIDs

  $randomizedorder = $this->getQuestionTable()->getQuestionIDs($quizID);
  //return $randomizedorder;
  //exit();
if($randomizedorder == 0){
	return $randomizedorder;
  //exit();
}else{
shuffle($randomizedorder);
//return $user_id;
//exit();
 
$data=array(
            'user_id'=>$user_id,
            'quiz_id'=>$testID,
            'order'=>json_encode($randomizedorder)
        );
//feed in the database
$result = $this->getQuestionRandTable()->createRandomization($data);
//return $result;
//exit();
if($result){
return $randomizedorder;
}
  }
  }

//lets verify a certificate
public function verify_certificate($from_number,$message)
    {
       $certUserID =$this->getUserCertificatesTable()->getCertUserID($from_number,$message)->user_id;
	   
	   //if we don't have a user_id with that certificate ID, then certificate is invalid
	   if($certUserID==0){
	   	
	   	$invalid_cert_message = $this->getSmsSettingsTable()->getInvalidCertMessage()->value;
		//We do a string replace to get the output message to be sent back
		$output = str_replace("{{cert_id}}", $message, $invalid_cert_message);		   
	   }else{
	   	//Get user's details using the $certUserID	 
	    	
	   	$user_details = $this->getUserTable()->getUserDetails($certUserID);
		//get institution id
		$institution_certificate_details = $this->getCertificatesTable()->getInstitutionDetails($message);
		 //$output = $institution_certificate_details ->institution_id;
	//get institution details
		$institution_details = $this->getUserTable()->getUserDetails($institution_certificate_details->institution_id);
	
	//get course details
		//$output = $institution_certificate_details->course_id;
	  $course_details = $this->getCourseTable()->getCourseDetails($institution_certificate_details->course_id);
		//Get Valid Certificate Message from Message Settings
		
		$valid_cert_message =  $this->getSmsSettingsTable()->getValidCertMessage()->value;
		
		//let do some string replace magic in our template
		$replace_with = array($user_details->first_name, $user_details->last_name, $message,$institution_details->first_name." ".$institution_details->last_name,
		$course_details->course_name,$course_details->course_short_name,$course_details->course_description,$institution_certificate_details->certificate_name);
        $search_for   = array("{{first_name}}", "{{last_name}}", "{{cert_id}}","{{institution_name}}",
		"{{course_name}}","{{course_short_name}}","{{course_description}}","{{certificate_name}}");
		$output = str_replace($search_for, $replace_with, $valid_cert_message);
		
		}  
	    
		return $output;
        //return $this->getResponse()->setContent(Json::encode($data));
    }
    
   public function getTestID($message){
    //get the test prefix
    $prefix=$this->getSmsSwitchTable()->getPrefix(2)->prefix;
    $prefix_length = strlen($prefix);
    $test_id = substr($message, $prefix_length);
    //getPrefix

    //$prefix = $action->prefix;
    //count the test prefix
    //delete the number of characters from the from
return $test_id;

   } 

   public function register($from_number,$message){
       
	     	//check user is registered
			$user_details = $this->getUserTable()->checkUserDetails($from_number);
			$user_exists = $user_details->from_number;
                                  
        if($user_exists >0){
                        	 
	        $progress = $user_details->progress;
			//return $progress;
			//exit();
			//progress used to determine the step we are at in the switch		
			switch ($progress) {
   			case 1: 
				//return 'hapa';
				//exit();
			$output=$this->getnationalID($from_number, $message,$user_details->id);
        	//welcome_request_first_name(); 
       		break;
			case 2:
    		$output=$this->thankyouMsg($from_number, $message,$user_details->id);
			break;
			
    		default:
			//create activity
			//create log
			$data=array(
                            'user_id'=>$user_details->id,
                            'activity'=>24,
                            //'quiz_id'=>$testID,
                            'message_received'=>$message
                        ); 
  		//create data points
  		$log = $this->getUserSmsInteractionsTable()->createActivity($data);
		//end of log creation
			
			$output=$this->getSmsSettingsTable()->getSetMessage('thank_you_already_registered')->value;
       		//$output=("Thank you, you are already Registered");
      		break;
			}
			return $output;
				
			}                      //we start session and insert user to db
                            //then assign progress=1
                            //then get first registration question


else{

  //create user
                        
		$id = $this->getUserTable()->createUser($from_number);
  //log activity
  // return $id;
  // exit();
    $data=array(
                            'user_id'=>$id,
                            'activity'=>1,
                            //'progress'=>1,
                            'message_received'=>$message
                        ); 
  		//create data points
  		$log = $this->getUserSmsInteractionsTable()->createActivity($data);
		         
    $first_question=$this->getSmsSettingsTable()->getSetMessage('appl_welcome_message')->value;
			
    }
      return $first_question;
						
		}
  



    public function checkSession($from_number,$message){


$user_details = $this->getUserTable()->checkUserDetails($from_number);
			$user_exists = $user_details->from_number;
                   
                        if($user_exists >0){
$user_session = $this->getUserTable()->checkUserDetails($from_number);
$session = $user_session->session;
//return $session;
//exit();
        //$session=$this->getUserTable()->chec($from_number);
        
	switch ($session) {
       
       case "1":
       $output=$this->register($from_number,$message,$user_session->id);
     break;    
        case "2":
       $output= $this->test($from_number,$message);
    break;    
        case "3":
       $output= $this->survey($from_number,$message);
    break;
	default:
       		 $output=$this->getSmsSettingsTable()->getSetMessage('menu_registered_user')->value;
      		break;
	 }
						}else {
    	$output=$this->getSmsSettingsTable()->getSetMessage('menu_unregistered_user')->value;    
    //break; 
	
    }

	 return $output;
    }
    
    public function getnationalID($from_number,$message,$user_id){
    
        $exploded = explode(" ", $message, 3);
       // print_r($exploded);
       //return $exploded; 
	   //exit(); 
       //in case we don't have the second name we through an error and request for it again
       if(empty($exploded[1])){
       	$data=array(
                            'user_id'=>$user_id,
                            'activity'=>4,
                            //'progress'=>2,
                            'message_received'=>$message
                        ); 
  		//create data points
  		$log = $this->getUserSmsInteractionsTable()->createActivity($data);
		
       	$output=$this->getSmsSettingsTable()->getSetMessage('request_full_name')->value;
       }else{
        $data=array(
        
		
            'first_name'=>(!empty($exploded[0])) ? $exploded[0] : null,
            'last_name'=>(!empty($exploded[1])) ? $exploded[1] : null,
            'other_name'=>(!empty($exploded[2])) ? $exploded[2] : null,
            'progress'=>2
            );
        //print_r($data);
        $this->getUserTable()->updateUser($data,$from_number);
		
		$data=array(
                            'user_id'=>$user_id,
                            'activity'=>2,
                            //'progress'=>2,
                            'message_received'=>$message
                        ); 
  		//create data points
  		$log = $this->getUserSmsInteractionsTable()->createActivity($data);
        
        //gets next question after inserting firstname and second name and udatees progress
         $output=$this->getSmsSettingsTable()->getSetMessage('app_national_id')->value;
		
        
	   }
	   return $output;
    }
    public function thankyouMsg($from_number,$message,$user_id){
    	//lets validate national ID to check if it it numeric
    	//$output = is_numeric($message);
		if(is_numeric($message)){
        $data=array(
            'national_id'=>$message,
            'progress'=>0,
            'session'=>0
        );
        $this->getUserTable()->updateUser($data,$from_number);
        //create logs
        $data=array(
                            'user_id'=>$user_id,
                            'activity'=>3,
                            //'progress'=>2,
                            'message_received'=>$message
                        ); 
  		//create data points
  		$log = $this->getUserSmsInteractionsTable()->createActivity($data);

       $test_to_take =  $user_details = $this->getUserTable()->checkUserDetails($from_number)->test_to_take;
       
        
        $output=$this->getSmsSettingsTable()->getSetMessage('app_thank_you_msg')->value;
    if(strlen($test_to_take)>1){
        //$thankyouMsg = $this->getSmsSettingsTable()->getSetMessage('app_thank_you_msg')->value;
        //$output = array();

        $message = $this->test($from_number,$test_to_take);
        //$output = $output." ".$message;
        $output = array($output,$message);
      }

		}
		else{
			//create log
			$data=array(
                            'user_id'=>$user_id,
                            'activity'=>5,
                            //'progress'=>2,
                            'message_received'=>$message
                        ); 
  		//create data points
  		$log = $this->getUserSmsInteractionsTable()->createActivity($data);
		//end of log creation
		$output = $this->getSmsSettingsTable()->getSetMessage('send_national_id')->value;
			
		}
		return $output;
    }
  
    


    public function addAction()
    {
    }

    public function editAction()
    {
    }

    public function deleteAction()
    {
    }


     public function getSmsTable()
    {
        if (!$this->SmsTable) {
            $sm = $this->getServiceLocator();
            $this->SmsTable = $sm->get('Sms\Model\SmsTable');
        }
        return $this->SmsTable;
    }
    public function getRegistrationTable()
    {
        if (!$this->RegistrationTable) {
            $sm = $this->getServiceLocator();
            $this->RegistrationTable = $sm->get('Sms\Model\RegistrationTable');
        }
        return $this->RegistrationTable;
    }
    
    public function getProgressTable()
    {
        if (!$this->ProgressTable) {
            $sm = $this->getServiceLocator();
            $this->ProgressTable = $sm->get('Sms\Model\ProgressTable');
        }
        return $this->ProgressTable;
    }
	
	public function getSmsgatewayTable()
    {
        if (!$this->SmsgatewayTable) {
            $sm = $this->getServiceLocator();
            $this->SmsgatewayTable = $sm->get('Sms\Model\SmsgatewayTable');
        }
        return $this->SmsgatewayTable;
    }
	
	public function getSmsSwitchTable()
    {
        if (!$this->SmsSwitchTable) {
            $sm = $this->getServiceLocator();
            $this->SmsSwitchTable = $sm->get('Sms\Model\SmsSwitchTable');
        }
        return $this->SmsSwitchTable;
    }
	//getUserTable
	public function getUserTable()
    {
        if (!$this->UserTable) {
            $sm = $this->getServiceLocator();
            $this->UserTable = $sm->get('Sms\Model\UserTable');
        }
        return $this->UserTable;
    }
	//get certificates table
	public function getCertificatesTable()
    {
        if (!$this->CertificatesTable) {
            $sm = $this->getServiceLocator();
            $this->CertificatesTable = $sm->get('Sms\Model\CertificatesTable');
        }
        return $this->CertificatesTable;
    }
	//Get course table
	public function getCourseTable()
    {
        if (!$this->CourseTable) {
            $sm = $this->getServiceLocator();
            $this->CourseTable = $sm->get('Sms\Model\CourseTable');
        }
        return $this->CourseTable;
    }
	//getUserCertificatesTable
	
	public function getUserCertificatesTable()
    {
        if (!$this->UserCertificatesTable) {
            $sm = $this->getServiceLocator();
            $this->UserCertificatesTable = $sm->get('Sms\Model\UserCertificatesTable');
        }
        return $this->UserCertificatesTable;
    }
	
	public function getSmsSettingsTable()
    {
        if (!$this->SmsSettingsTable) {
            $sm = $this->getServiceLocator();
            $this->SmsSettingsTable = $sm->get('Sms\Model\SmsSettingsTable');
        }
        return $this->SmsSettingsTable;
    }
		//quiztable
    public function getQuizTable()
    {
        if (!$this->QuizTable) {
            $sm = $this->getServiceLocator();
            $this->QuizTable = $sm->get('Sms\Model\QuizTable');
        }
        return $this->QuizTable;
    }
    public function getQuestionTable()
    {
        if (!$this->QuestionTable) {
            $sm = $this->getServiceLocator();
            $this->QuestionTable = $sm->get('Sms\Model\QuestionTable');
        }
        return $this->QuestionTable;
    }
    //choices table
    public function getChoicesTable()
    {
        if (!$this->ChoicesTable) {
            $sm = $this->getServiceLocator();
            $this->ChoicesTable = $sm->get('Sms\Model\ChoicesTable');
        }
        return $this->ChoicesTable;
    }

    public function getQuestionRandTable()
    {
        if (!$this->QuestionRandTable) {
            $sm = $this->getServiceLocator();
            $this->QuestionRandTable = $sm->get('Sms\Model\QuestionRandTable');
        }
        return $this->QuestionRandTable;
    }
    public function getQuestionResponsesTable()
    {
        if (!$this->QuestionResponsesTable) {
            $sm = $this->getServiceLocator();
            $this->QuestionResponsesTable = $sm->get('Sms\Model\QuestionResponsesTable');
        }
        return $this->QuestionResponsesTable;
    }
	
	public function getUserSmsInteractionsTable()
    {
        if (!$this->UserSmsInteractionsTable) {
            $sm = $this->getServiceLocator();
            $this->UserSmsInteractionsTable = $sm->get('Sms\Model\UserSmsInteractionsTable');
        }
        return $this->UserSmsInteractionsTable;
    }
	
	public function getUserAssignmentTable()
    {
        if (!$this->UserAssignmentTable) {
            $sm = $this->getServiceLocator();
            $this->UserAssignmentTable = $sm->get('Sms\Model\UserAssignmentTable');
        }
        return $this->UserAssignmentTable;
    }
	
	public function getInvitationTable()
    {
        if (!$this->InvitationTable) {
            $sm = $this->getServiceLocator();
            $this->InvitationTable = $sm->get('Sms\Model\InvitationTable');
        }
        return $this->InvitationTable;
    }
	
	public function getClassTable()
    {
        if (!$this->ClassTable) {
            $sm = $this->getServiceLocator();
            $this->ClassTable = $sm->get('Sms\Model\ClassTable');
        }
        return $this->ClassTable;
    }
	
}