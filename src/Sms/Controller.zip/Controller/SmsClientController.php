<?php

namespace Sms\Controller;
 
use Zend\Mvc\Controller\AbstractActionController;
use Zend\Http\Client as HttpClient;
 
class SmsClientController extends AbstractActionController
{
	protected $SmsgatewayTable;
    public function indexAction()
    {
    	//echo 'hapa';
		
    	$sms_gateway =$this->getSmsgatewayTable()->getSmsgateway();
       // print_r($sms_gateway);
	   // exit();
//lets get the sms_gateway_id and use it to 
	 	    $sms_gateway_id = $sms_gateway->id;
	  
//now that we have the gateway id, lets use the gateway to get the incoming message details from our gateway

	  	    $received_msg =$this->get_message_details($sms_gateway_id); 
		  
		  // print_r($received_msg);
	   // exit();
		  
        $client = new HttpClient();
        $client->setAdapter('Zend\Http\Client\Adapter\Curl');
         
        $method = $this->params()->fromQuery('method', 'get');
		$client->setUri('http://akengo.com/sms/public/Sms/SmsRestful');
		// print_r($client);
	   // exit();
		
		 //$client->setUri('http://localhost:80'.$this->getRequest()->getBaseUrl().'/Sms?from=254&message=Akengo');
		 
		 if(!empty($_REQUEST['task'])){
		 // $client->setMethod('POST');
                // $client->setParameterPOST(array('from'=>$received_msg['from_number'],'message'=>'invitation','sms_gateway_id'=>$sms_gateway_id));
// 		 	
			$SmsToBeSent = $_GET;
		 if (is_array($SmsToBeSent)){
         $records = array();         
         foreach ($SmsToBeSent as $key => $data) {
         	//we need to change the status of the sms we have sent        	
		   
          array_push($records, array('message' => $key."=".$data, 'to'=>'+254728355429'));
           # code...
           //change the status right away too
		  
		 }
		  }else{
		 	$records = array('message'=>"All messeges sent", 'to'=>'');
		 }
		 
		  $sms_array= array();
				$sms_array[] = array('success'=>"true",'secret'=>"",'task'=>"send",'messages'=>$records);
				$payload= array('payload'=>$sms_array[0]);
				//header('content-type: application/json; charset=utf-8');
				//echo json_encode($payload);					
         return json_encode($payload);
		 exit();
			
		}else{
		 
		 $client->setMethod('POST');
                $client->setParameterPOST(array('from'=>$received_msg['from_number'],'message'=>$received_msg['message'],'sms_gateway_id'=>$sms_gateway_id));
		 
		 }
		$response = $client->send();
        if (!$response->isSuccess()) {
            // report failure
            $message = $response->getStatusCode() . ': ' . $response->getReasonPhrase();
             
            $response = $this->getResponse();
            $response->setContent($message);
            return $response;
		}
        //print_r($response);
		//exit();
        $body = $response->getBody();
         
        $response = $this->getResponse();
		   
        $response->setContent($body);
         
        return $response;
		 
		 
		
    }
public function getSmsgatewayTable()
    {
        if (!$this->SmsgatewayTable) {
            $sm = $this->getServiceLocator();
            $this->SmsgatewayTable = $sm->get('Sms\Model\SmsgatewayTable');
        }
        return $this->SmsgatewayTable;
    }
	
	public function get_message_details($sms_gateway_id){
		//If we are using SMSSync id=1 and we do the following
	if($sms_gateway_id==1){
		$msg_details['from_number'] = trim($_REQUEST['from']);
		if(!empty($_REQUEST['message'])){
			$msg_details['message'] = trim($_REQUEST['message']);
		}
		
		if(!empty($_REQUEST['task'])){
			$msg_details['task'] = trim($_REQUEST['task']);
		}
		return $msg_details;
		
	}
	//If we are using Africastalking we do the following
	if($sms_gateway_id==2){
		//we will write this code from Africastalking documentation
		
	}
	/* future sms gateway will be setup here to be used
	 if($sms_gateway_id==X){
		we will write this code from Africastalking documentation
		
	}*/

	else{
		//
	}
		
	}

}