<?php
namespace Sms\Model;

class UserCertificatesTableData
{
    public $user_id;
    //public $category;
    //public $message_id;
    //public $from_number;

    public function exchangeArray($data)
    {
        $this->user_id     = (!empty($data['user_id'])) ? $data['user_id'] : null;
        //$this->message = (!empty($data['message'])) ? $data['message'] : null;
        //$this->message_id  = (!empty($data['message_id'])) ? $data['message_id'] : null;
        //$this->from_number  = (!empty($data['from_number'])) ? $data['from_number'] : null;
    }
}