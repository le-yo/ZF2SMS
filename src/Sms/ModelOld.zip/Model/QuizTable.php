<?php
namespace Sms\Model;

use Zend\Db\TableGateway\TableGateway;

class QuizTable
{
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }


   public function getQuizDetails($id){
   	$rowset = $this->tableGateway->select(array('id' => $id));
		$row = $rowset->current();
		//print_r($row);
		if(!$row){
			$row = array('id' => 0);
			
			$row = (object) $row;
			//$this->action_id = 7;
			
		}
		return $row;
   }

   
}