<?php
namespace Sms\Model;

use Zend\Db\TableGateway\TableGateway;

class UserCertificatesTable
{
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }


   public function getCertUserID($from_number,$message){
   	
		$rowset = $this->tableGateway->select(array('certificate_code' => $message));
		$row = $rowset->current();
		//print_r($row);
		if(!$row){
			$row = array('user_id' => 0);
			
			$row = (object) $row;
			//$this->action_id = 7;
			
		}
		return $row;
		
	}

   
}