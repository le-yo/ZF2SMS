<?php
namespace Sms\Model;

class CertificatesTableData
{
    public $institution_id;
    public $certificate_name;
    public $course_id;
    //public $from_number;

    public function exchangeArray($data)
    {
        $this->institution_id     = (!empty($data['institution_id'])) ? $data['institution_id'] : null;
        $this->certificate_name = (!empty($data['certificate_name'])) ? $data['certificate_name'] : null;
        $this->course_id  = (!empty($data['course_id'])) ? $data['course_id'] : null;
        //$this->from_number  = (!empty($data['from_number'])) ? $data['from_number'] : null;
    }
}